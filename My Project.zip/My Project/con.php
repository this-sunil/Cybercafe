
<?php
$con=mysqli_connect("localhost","root","password","food");
if(!$con)
{
	echo "disconnect";
}
else
{
	echo "success how are you";
}
$q="create table food(fno int primary key,fname varchar(20),price float)";
$res=mysqli_query($q,$con);
echo $res;
?>
